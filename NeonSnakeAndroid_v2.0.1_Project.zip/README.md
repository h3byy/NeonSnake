# Neon Snake Android — v2.0

A native Android arcade game built with Kotlin and Jetpack Compose.

## v2.0 features
- Persistent top-10 local leaderboard and personal best
- Original synthesized looping arcade soundtrack (toggle in settings)
- Animated pulsing food and bonus pickups
- Bonus food worth +30 points, normal food worth +10
- Three maps: Neon Grid, Crossfire, Cyber Maze
- Four snake color skins
- Swipe and on-screen directional controls
- Pause/resume, score, levels, collision/game-over handling
- Settings persist between app launches

## Build a debug APK in Android Studio
1. Install Android Studio and Android SDK Platform 35.
2. Open this project folder.
3. Wait for Gradle sync to complete.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK output location. Usually:
   `app/build/outputs/apk/debug/app-debug.apk`

## Build APK with GitHub Actions
A workflow is included at `.github/workflows/android.yml`.
Push this project to a GitHub repository on the `main` branch, then open **Actions** and select **Build Neon Snake APK**. Download the `Neon-Snake-debug-apk` artifact from a successful run.

## Important
This environment does not contain Android SDK or Gradle, so the APK could not be compiled or tested here. The archive contains the complete source project and a CI workflow to build the APK in Android Studio or GitHub Actions. Please test the APK on a device before publishing.


## v2.0.1 build fix
Java and Kotlin bytecode targets are both configured for JVM 17.
