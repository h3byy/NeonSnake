package com.example.neonsnake

import android.content.Context
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.ToneGenerator
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.random.Random

private val Bg = Color(0xFF070B18)
private val Panel = Color(0xFF111A2E)
private val Cyan = Color(0xFF35F2E0)
private val Pink = Color(0xFFFF4FD8)
private val Lime = Color(0xFFB8FF5C)
private val Gold = Color(0xFFFFC857)

private data class Cell(val x: Int, val y: Int)
private enum class Dir { UP, DOWN, LEFT, RIGHT }
private enum class Screen { MENU, GAME, SETTINGS, LEADERBOARD }
private data class Skin(val name: String, val body: Color, val head: Color, val food: Color)
private data class MapStyle(val name: String, val walls: Set<Cell>)

private val skins = listOf(
    Skin("Cyber Cyan", Cyan, Color.White, Pink),
    Skin("Toxic Green", Lime, Color.White, Pink),
    Skin("Violet Pulse", Color(0xFF9B7BFF), Color.White, Gold),
    Skin("Solar Gold", Gold, Color.White, Color(0xFFFF6B6B))
)

private const val COLS = 20
private const val ROWS = 28

private fun mapOptions(): List<MapStyle> {
    val cross = buildSet {
        for (y in 4..10) add(Cell(10, y))
        for (y in 17..23) add(Cell(10, y))
        for (x in 3..7) add(Cell(x, 12))
        for (x in 12..16) add(Cell(x, 12))
    }
    val maze = buildSet {
        for (y in 3..9) add(Cell(5, y))
        for (y in 17..24) add(Cell(5, y))
        for (y in 4..11) add(Cell(14, y))
        for (y in 16..23) add(Cell(14, y))
        for (x in 8..11) add(Cell(x, 9))
        for (x in 8..11) add(Cell(x, 19))
    }
    return listOf(MapStyle("Neon Grid", emptySet()), MapStyle("Crossfire", cross), MapStyle("Cyber Maze", maze))
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NeonSnakeApp(applicationContext) }
    }
}

@Composable
private fun NeonSnakeApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("neon_snake_v2", Context.MODE_PRIVATE) }
    var best by remember { mutableIntStateOf(prefs.getInt("best", 0)) }
    var records by remember { mutableStateOf(prefs.getString("records", "")!!.split(",").mapNotNull { it.toIntOrNull() }.sortedDescending().take(10)) }
    var soundOn by remember { mutableStateOf(prefs.getBoolean("sound", true)) }
    var musicOn by remember { mutableStateOf(prefs.getBoolean("music", false)) }
    var skinIndex by remember { mutableIntStateOf(prefs.getInt("skin", 0).coerceIn(skins.indices)) }
    var mapIndex by remember { mutableIntStateOf(prefs.getInt("map", 0).coerceIn(mapOptions().indices)) }
    val skin = skins[skinIndex]
    val map = mapOptions()[mapIndex]
    val tone = remember { ToneGenerator(AudioManager.STREAM_MUSIC, 45) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }

    DisposableEffect(Unit) {
        onDispose {
            player?.release()
            tone.release()
        }
    }
    LaunchedEffect(musicOn) {
        if (musicOn) {
            if (player == null) {
                player = MediaPlayer.create(context, R.raw.arcade_loop)?.apply { isLooping = true; setVolume(0.28f, 0.28f) }
            }
            player?.start()
        } else {
            player?.pause()
        }
    }

    val walls = map.walls
    var screen by remember { mutableStateOf(Screen.MENU) }
    var snake by remember { mutableStateOf(listOf(Cell(3, 14), Cell(2, 14), Cell(1, 14))) }
    var food by remember { mutableStateOf(Cell(12, 10)) }
    var bonus by remember { mutableStateOf<Cell?>(null) }
    var bonusTicks by remember { mutableIntStateOf(0) }
    var direction by remember { mutableStateOf(Dir.RIGHT) }
    var queuedDirection by remember { mutableStateOf(Dir.RIGHT) }
    var score by remember { mutableIntStateOf(0) }
    var running by remember { mutableStateOf(false) }
    var paused by remember { mutableStateOf(false) }
    var gameOver by remember { mutableStateOf(false) }

    fun beep(success: Boolean) {
        if (soundOn) tone.startTone(if (success) ToneGenerator.TONE_PROP_BEEP else ToneGenerator.TONE_PROP_NACK, 110)
    }
    fun spawnFood(body: List<Cell>): Cell {
        var cell: Cell
        do { cell = Cell(Random.nextInt(COLS), Random.nextInt(ROWS)) } while (cell in body || cell in walls || cell == bonus)
        return cell
    }
    fun spawnBonus(body: List<Cell>): Cell {
        var cell: Cell
        do { cell = Cell(Random.nextInt(COLS), Random.nextInt(ROWS)) } while (cell in body || cell in walls || cell == food)
        return cell
    }
    fun saveRecord(value: Int) {
        if (value <= 0) return
        val updated = (records + value).sortedDescending().take(10)
        records = updated
        prefs.edit().putString("records", updated.joinToString(",")).apply()
        if (value > best) {
            best = value
            prefs.edit().putInt("best", best).apply()
        }
    }
    fun startGame() {
        snake = listOf(Cell(3, 14), Cell(2, 14), Cell(1, 14))
        food = spawnFood(snake)
        bonus = null
        bonusTicks = 0
        direction = Dir.RIGHT
        queuedDirection = Dir.RIGHT
        score = 0
        gameOver = false
        paused = false
        running = true
        screen = Screen.GAME
    }
    fun turn(next: Dir) {
        val reverse = (direction == Dir.UP && next == Dir.DOWN) ||
            (direction == Dir.DOWN && next == Dir.UP) ||
            (direction == Dir.LEFT && next == Dir.RIGHT) ||
            (direction == Dir.RIGHT && next == Dir.LEFT)
        if (!reverse) queuedDirection = next
    }

    LaunchedEffect(running, paused, gameOver, screen, mapIndex) {
        while (running && !paused && !gameOver && screen == Screen.GAME) {
            delay((155L - (score / 5) * 7L).coerceAtLeast(62L))
            direction = queuedDirection
            val head = snake.first()
            val next = when (direction) {
                Dir.UP -> Cell(head.x, head.y - 1)
                Dir.DOWN -> Cell(head.x, head.y + 1)
                Dir.LEFT -> Cell(head.x - 1, head.y)
                Dir.RIGHT -> Cell(head.x + 1, head.y)
            }
            val ateNormal = next == food
            val ateBonus = next == bonus
            val grows = ateNormal || ateBonus
            val collisionBody = if (grows) snake else snake.dropLast(1)
            if (next.x !in 0 until COLS || next.y !in 0 until ROWS || next in collisionBody || next in walls) {
                running = false
                gameOver = true
                saveRecord(score)
                beep(false)
            } else {
                snake = if (grows) listOf(next) + snake else listOf(next) + snake.dropLast(1)
                if (ateNormal) {
                    score += 10
                    beep(true)
                    if (score > 0 && score % 50 == 0) {
                        bonus = spawnBonus(snake)
                        bonusTicks = 55
                    }
                    food = spawnFood(snake)
                } else if (ateBonus) {
                    score += 30
                    bonus = null
                    bonusTicks = 0
                    beep(true)
                } else if (bonus != null) {
                    bonusTicks--
                    if (bonusTicks <= 0) bonus = null
                }
                if (score > best) {
                    best = score
                    prefs.edit().putInt("best", best).apply()
                }
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Cyan, onPrimary = Bg)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            when (screen) {
                Screen.MENU -> MenuScreen(best, onPlay = { startGame() }, onSettings = { screen = Screen.SETTINGS }, onRecords = { screen = Screen.LEADERBOARD })
                Screen.SETTINGS -> SettingsScreen(
                    skinIndex, mapIndex, soundOn, musicOn,
                    onSkin = { skinIndex = it; prefs.edit().putInt("skin", it).apply() },
                    onMap = { mapIndex = it; prefs.edit().putInt("map", it).apply() },
                    onSound = { soundOn = it; prefs.edit().putBoolean("sound", it).apply() },
                    onMusic = { musicOn = it; prefs.edit().putBoolean("music", it).apply() },
                    onBack = { screen = Screen.MENU }
                )
                Screen.LEADERBOARD -> LeaderboardScreen(records, onBack = { screen = Screen.MENU })
                Screen.GAME -> GameScreen(
                    snake, food, bonus, score, best, skin, walls, running, paused, gameOver,
                    onTurn = { turn(it) }, onPause = { paused = !paused },
                    onRestart = { startGame() }, onMenu = { if (!gameOver) saveRecord(score); running = false; screen = Screen.MENU }
                )
            }
        }
    }
}

@Composable
private fun MenuScreen(best: Int, onPlay: () -> Unit, onSettings: () -> Unit, onRecords: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("NEON", color = Cyan, fontSize = 48.sp, fontWeight = FontWeight.Black, letterSpacing = 7.sp)
        Text("SNAKE", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.Black, letterSpacing = 9.sp)
        Text("ARCADE REIMAGINED", color = Color(0xFF8290B2), fontSize = 10.sp, letterSpacing = 3.sp)
        Spacer(Modifier.height(34.dp))
        StatCard("KİŞİSEL REKOR", best.toString(), Modifier.fillMaxWidth(), Gold)
        Spacer(Modifier.height(20.dp))
        Button(onClick = onPlay, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp)) {
            Text("OYNA", fontWeight = FontWeight.Black, letterSpacing = 2.sp)
        }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = onRecords, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text("REKORLAR TABLOSU", color = Cyan) }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = onSettings, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text("AYARLAR", color = Cyan) }
        Spacer(Modifier.height(30.dp))
        Text("YEMİ TOPLA • BONUSU YAKALA • REKORUNU KIR", color = Color(0xFF657493), fontSize = 9.sp, letterSpacing = 1.sp)
    }
}

@Composable
private fun SettingsScreen(
    skinIndex: Int, mapIndex: Int, soundOn: Boolean, musicOn: Boolean,
    onSkin: (Int) -> Unit, onMap: (Int) -> Unit, onSound: (Boolean) -> Unit, onMusic: (Boolean) -> Unit, onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("AYARLAR", color = Cyan, fontSize = 26.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
        Spacer(Modifier.height(18.dp))
        Text("YILAN GÖRÜNÜMÜ", color = Color.White, fontWeight = FontWeight.Bold)
        skins.forEachIndexed { i, s ->
            ChoiceRow(s.name, i == skinIndex, s.body) { onSkin(i) }
        }
        Spacer(Modifier.height(14.dp))
        Text("HARİTA", color = Color.White, fontWeight = FontWeight.Bold)
        mapOptions().forEachIndexed { i, m ->
            ChoiceRow(m.name, i == mapIndex, Pink) { onMap(i) }
        }
        Spacer(Modifier.height(12.dp))
        SettingSwitch("Ses efektleri", soundOn, onSound)
        SettingSwitch("Arka plan müziği", musicOn, onMusic)
        Spacer(Modifier.weight(1f))
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth().height(48.dp)) { Text("GERİ DÖN", color = Cyan) }
    }
}

@Composable
private fun ChoiceRow(label: String, selected: Boolean, color: Color, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).background(if (selected) Color(0xFF20334A) else Panel, RoundedCornerShape(10.dp)).padding(horizontal = 10.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(13.dp).background(color, RoundedCornerShape(4.dp)))
        Spacer(Modifier.width(10.dp))
        Text(label, color = Color.White, modifier = Modifier.weight(1f), fontSize = 13.sp)
        RadioButton(selected, onClick, colors = RadioButtonDefaults.colors(selectedColor = Cyan))
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f))
        Switch(checked, onCheckedChange = onChange)
    }
}

@Composable
private fun LeaderboardScreen(records: List<Int>, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("REKORLAR", color = Cyan, fontSize = 27.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
        Spacer(Modifier.height(20.dp))
        if (records.isEmpty()) {
            Text("Henüz kayıt yok. İlk rekoru sen kır!", color = Color(0xFF8290B2))
        } else {
            records.forEachIndexed { i, value ->
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Panel, RoundedCornerShape(12.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("#${i + 1}", color = if (i == 0) Gold else Cyan, fontWeight = FontWeight.Black, modifier = Modifier.width(48.dp))
                    Text("OYUNCU", color = Color(0xFF8290B2), modifier = Modifier.weight(1f))
                    Text(value.toString(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
            }
        }
        Spacer(Modifier.weight(1f))
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text("ANA MENÜ", color = Cyan) }
    }
}


@Composable
private fun GameScreen(
    snake: List<Cell>, food: Cell, bonus: Cell?, score: Int, best: Int, skin: Skin, walls: Set<Cell>,
    running: Boolean, paused: Boolean, gameOver: Boolean,
    onTurn: (Dir) -> Unit, onPause: () -> Unit, onRestart: () -> Unit, onMenu: () -> Unit
) {
    val pulse by rememberInfiniteTransition(label = "foodPulse").animateFloat(
        initialValue = 0.76f, targetValue = 1.10f,
        animationSpec = infiniteRepeatable(tween(650), RepeatMode.Reverse), label = "pulse"
    )

    Column(
        Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Compact header keeps navigation visible on shorter phones.
        Row(Modifier.fillMaxWidth().height(42.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "NEON SNAKE", color = skin.body, fontSize = 20.sp,
                fontWeight = FontWeight.Black, letterSpacing = 1.5.sp,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onMenu, contentPadding = PaddingValues(horizontal = 8.dp)) {
                Text("MENÜ", color = Color(0xFF8290B2), fontSize = 12.sp)
            }
            TextButton(
                onClick = onPause,
                enabled = running && !gameOver,
                contentPadding = PaddingValues(horizontal = 8.dp)
            ) {
                Text(if (paused) "DEVAM" else "DURAKLAT", color = Cyan, fontSize = 12.sp)
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            StatCard("SKOR", score.toString(), Modifier.weight(1f), skin.body)
            StatCard("REKOR", best.toString(), Modifier.weight(1f), Gold)
            StatCard("SEVİYE", (1 + score / 50).toString(), Modifier.weight(1f), Pink)
        }

        Spacer(Modifier.height(7.dp))

        // Board takes the remaining space but is capped by its natural portrait ratio.
        BoxWithConstraints(
            Modifier.weight(1f, fill = true).fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            val boardWidth = maxWidth
            val boardHeight = (boardWidth * (ROWS.toFloat() / COLS.toFloat())).coerceAtMost(maxHeight)
            Box(
                Modifier.width(boardHeight * (COLS.toFloat() / ROWS.toFloat()))
                    .height(boardHeight)
                    .background(Panel, RoundedCornerShape(15.dp))
                    .padding(6.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(Modifier.fillMaxSize().pointerInput(running, paused, gameOver) {
                    var dx = 0f
                    var dy = 0f
                    detectDragGestures(
                        onDragStart = { dx = 0f; dy = 0f },
                        onDrag = { change, drag -> change.consume(); dx += drag.x; dy += drag.y },
                        onDragEnd = {
                            if (abs(dx) > abs(dy)) onTurn(if (dx > 0) Dir.RIGHT else Dir.LEFT)
                            else onTurn(if (dy > 0) Dir.DOWN else Dir.UP)
                        }
                    )
                }) {
                    val cw = size.width / COLS
                    val ch = size.height / ROWS
                    for (x in 0..COLS) drawLine(Color(0xFF1B2942), Offset(x*cw, 0f), Offset(x*cw, size.height), 1f)
                    for (y in 0..ROWS) drawLine(Color(0xFF1B2942), Offset(0f, y*ch), Offset(size.width, y*ch), 1f)
                    walls.forEach { c ->
                        drawRoundRect(
                            Color(0xFF334767),
                            Offset(c.x*cw + 1, c.y*ch + 1),
                            androidx.compose.ui.geometry.Size(cw-2, ch-2),
                            androidx.compose.ui.geometry.CornerRadius(cw*.15f)
                        )
                    }
                    val fx = (food.x+.5f)*cw
                    val fy = (food.y+.5f)*ch
                    drawCircle(skin.food.copy(alpha=.18f), cw*.48f*pulse, Offset(fx,fy))
                    drawCircle(skin.food, cw*.25f, Offset(fx,fy))
                    bonus?.let {
                        val bx=(it.x+.5f)*cw
                        val by=(it.y+.5f)*ch
                        drawCircle(Gold.copy(alpha=.22f), cw*.52f*pulse, Offset(bx,by))
                        drawCircle(Gold, cw*.31f, Offset(bx,by))
                    }
                    snake.forEachIndexed { i, c ->
                        val inset = cw*.07f
                        drawRoundRect(
                            if (i==0) skin.head else skin.body,
                            Offset(c.x*cw+inset,c.y*ch+inset),
                            androidx.compose.ui.geometry.Size(cw-inset*2,ch-inset*2),
                            androidx.compose.ui.geometry.CornerRadius(cw*.22f)
                        )
                    }
                }

                if (!running || paused || gameOver) {
                    Column(
                        Modifier.fillMaxWidth(.82f)
                            .background(Color(0xE6070B18), RoundedCornerShape(16.dp))
                            .padding(horizontal = 14.dp, vertical = 16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            when { gameOver -> "OYUN BİTTİ"; paused -> "DURAKLATILDI"; else -> "HAZIR" },
                            color = if (gameOver) Pink else Cyan,
                            fontSize = 20.sp, fontWeight = FontWeight.Black
                        )
                        Spacer(Modifier.height(5.dp))
                        Text(
                            if (gameOver) "Skor: $score" else if (paused) "Devam etmek için dokun" else "Başlamak için dokun",
                            color = Color.White
                        )
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = if (gameOver) onRestart else if (paused) onPause else onRestart,
                            modifier = Modifier.fillMaxWidth(.9f).height(48.dp)
                        ) {
                            Text(if (gameOver) "TEKRAR OYNA" else if (paused) "DEVAM ET" else "OYNA")
                        }
                        if (gameOver) {
                            TextButton(onClick = onMenu) { Text("ANA MENÜ", color = Cyan) }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(5.dp))
        Text(
            "PEMBE: +10 PUAN     ALTIN: +30 BONUS",
            color = Color(0xFF8290B2), fontSize = 9.sp, letterSpacing = .5.sp
        )
        Spacer(Modifier.height(5.dp))

        // Larger, consistent 3x3 directional pad for touch accuracy.
        val keySize = 62.dp
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            DirectionButton("▲", keySize) { onTurn(Dir.UP) }
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                DirectionButton("◀", keySize) { onTurn(Dir.LEFT) }
                Spacer(Modifier.width(66.dp))
                DirectionButton("▶", keySize) { onTurn(Dir.RIGHT) }
            }
            DirectionButton("▼", keySize) { onTurn(Dir.DOWN) }
        }
        Spacer(Modifier.height(3.dp))
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier, accent: Color) {
    Column(modifier.background(Panel, RoundedCornerShape(11.dp)).padding(vertical = 9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Color(0xFF8290B2), fontSize = 8.sp, letterSpacing = 1.sp)
        Text(value, color = accent, fontSize = 19.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun DirectionButton(label: String, size: androidx.compose.ui.unit.Dp = 62.dp, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.size(size),
        contentPadding = PaddingValues(0.dp),
        shape = RoundedCornerShape(15.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1A2942))
    ) {
        Text(label, color = Cyan, fontSize = 27.sp, fontWeight = FontWeight.Black)
    }
}
